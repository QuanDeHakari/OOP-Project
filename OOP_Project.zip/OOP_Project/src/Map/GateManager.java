package Map;

import java.awt.Image;
import java.util.HashMap;

import javax.swing.*;

import Character.Strayer;

public class GateManager {
	private JLayeredPane PanelHolder;
	private JFrame Menu;
	private MapManager manager;
	private JLabel A1Gate;
	private JLabel B2Gate;
	private int countDown = 1;
	private CommonGate CommonGate;
	private CorruptedGate CorruptedGate;
	int Animation1 = 1, Animation2 = 3;
	private HashMap<JLabel, JLabel> Gate = new HashMap<JLabel, JLabel>();
	ImageIcon Cgate1Icon = new ImageIcon(new ImageIcon("src/All Object/CommonGate1.png").getImage().getScaledInstance(180, 270, Image.SCALE_DEFAULT));
	ImageIcon Cgate2Icon = new ImageIcon(new ImageIcon("src/All Object/CommonGate2.png").getImage().getScaledInstance(180, 270, Image.SCALE_DEFAULT));
	ImageIcon Cgate3Icon = new ImageIcon(new ImageIcon("src/All Object/CommonGate3.png").getImage().getScaledInstance(180, 270, Image.SCALE_DEFAULT));
	
	public GateManager(JFrame Menu, JLayeredPane PanelHolder, MapManager manager) {
		this.Menu = Menu;
		this.PanelHolder = PanelHolder;
		this.manager = manager;
		
		A1Gate = new JLabel();
		A1Gate.setBounds(300, 150, 180, 270);
		A1Gate.setIcon(Cgate1Icon);
		Timer t1 = new Timer(2000, e ->{
			switch (Animation1%4){
				case 0: 
					A1Gate.setIcon(Cgate1Icon);
					break;
				case 1: 
					A1Gate.setIcon(Cgate2Icon);
					break;
				case 2: 
					A1Gate.setIcon(Cgate3Icon);
					break;
				case 3: 
					A1Gate.setIcon(Cgate2Icon);
					break;
			}
			Animation1++;
		});
		t1.start();
		JLabel A1GateBound = new JLabel();
		A1GateBound.setBounds(330, 390, 120, 30);
		Gate.put(A1Gate, A1GateBound);
		
		B2Gate = new JLabel();
		B2Gate.setBounds(450, 120, 180, 270);
		B2Gate.setIcon(Cgate3Icon);
		Timer t2 = new Timer(2000, e ->{
			switch (Animation1%4){
				case 0: 
					B2Gate.setIcon(Cgate1Icon);
					break;
				case 1: 
					B2Gate.setIcon(Cgate2Icon);
					break;
				case 2: 
					B2Gate.setIcon(Cgate3Icon);
					break;
				case 3: 
					B2Gate.setIcon(Cgate2Icon);
					break;
			}
			Animation2++;
		});
		t2.start();
		JLabel B2GateBound = new JLabel();
		B2GateBound.setBounds(480, 360, 120, 30);
		Gate.put(B2Gate, B2GateBound);
	}

	public HashMap<JLabel, JLabel> getGate() {
		return Gate;
	}

	public void setGate(HashMap<JLabel, JLabel> gate) {
		Gate = gate;
	}
	public JLabel getA1Gate() {
		return A1Gate;
	}
	public JLabel getB2Gate() {
		return B2Gate;
	}
	public void getIntoGate(Strayer Strayer) {
		if (countDown>0) {
			CommonGate = new CommonGate(Menu, PanelHolder, manager);
			CommonGate.getComEntrance().setVisible(true);
			Strayer.setLocation(420, 480);
			CommonGate.getComEntrance().setStrayer(Strayer);
			countDown--;
		} else if (countDown==0) {
			CorruptedGate = new CorruptedGate(Menu, PanelHolder, manager);
			CorruptedGate.getCorEntrance().setVisible(true);
			Strayer.setLocation(420, 480);
			CorruptedGate.getCorEntrance().setStrayer(Strayer);
		}
	}
}
