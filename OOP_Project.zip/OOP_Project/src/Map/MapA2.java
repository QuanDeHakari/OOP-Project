package Map;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import javax.swing.*;

import Character.Strayer;

public class MapA2 extends JLayeredPane implements Map{

	private JFrame Menu;
	private MapManager manager;
	private ArrayList<JComponent> BoundedComponent = new ArrayList<JComponent>();
	private ArrayList<JComponent> EffectedComponent = new ArrayList<JComponent>();
	private HashMap<JComponent, JComponent> Object = new HashMap<JComponent, JComponent>();
	private Strayer Strayer;
	private int LMove = 0, RMove = 0, FMove = 0, BMove = 0;
	private String direction;
	private boolean LA = false, RA = false, BA = false, FA = false;
	private Image A2Image = new ImageIcon("src/World Map/A2.png").getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
	
	private Timer timer = new Timer(200, e->{
		if (direction != null) {
		switch (direction) {
		case "left":
			if (LMove+RMove==0)	Strayer.setIcon(Strayer.Left);
			else Strayer.setIcon(LA?Strayer.LeftWalk1:Strayer.LeftWalk2);
			LA = !LA;
			break;
		case "right":
			if (LMove+RMove==0)	Strayer.setIcon(Strayer.Right);
			else Strayer.setIcon(RA?Strayer.RightWalk1:Strayer.RightWalk2);
			RA = !RA;
			break;
		case "back":
			if (FMove+BMove==0)	Strayer.setIcon(Strayer.Back);
			else Strayer.setIcon(BA?Strayer.BackWalk1:Strayer.BackWalk2);
			BA = !BA;
			break;
		case "front":
			if (FMove+BMove==0)	Strayer.setIcon(Strayer.Front);
			else Strayer.setIcon(FA?Strayer.FrontWalk1:Strayer.FrontWalk2);
			FA = !FA;
			break;
		}
		reArrange();
		boolean overlaps = false;
		for (JComponent bounded : BoundedComponent)
			if (bounded.getBounds().intersects(new Rectangle(Strayer.getX()+LMove+RMove, Strayer.getY()+90+FMove+BMove, 60, 30))) overlaps = true;
		if (overlaps==false) Strayer.setLocation(Strayer.getX() + LMove + RMove,Strayer.getY() + FMove + BMove);
		
		boolean oneWay = false;
		if (Strayer.getX()>870) {
			oneWay = true;
			moveToRight(Menu);
		}
		if (oneWay==false)
			if (Strayer.getY()+60<0) moveToTop(Menu);
		}
	});
	private KeyListener listener = new KeyListener() {

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			switch(e.getKeyChar()) {
			case 'a':
				if (direction == null) direction = "left";
				LMove = -30;
				break;
			case 'd':
				if (direction == null) direction = "right";
				RMove = 30;
				break;
			case 'w':;
				if (direction == null) direction = "back";
				BMove = -30;
				break;
			case 's':
				if (direction == null) direction = "front";
				FMove = 30;
				break;
			}
			timer.start();
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			switch(e.getKeyChar()) {
			case 'a':
				if (direction == "left") {
					direction = null;
					Strayer.setIcon(Strayer.Left);
				}
				LMove = 0;
				break;
			case 'd':
				if (direction == "right") {
					direction = null;
					Strayer.setIcon(Strayer.Right);
				}
				RMove = 0;
				break;
			case 'w':
				if (direction == "back") {
					direction = null;
					Strayer.setIcon(Strayer.Back);
				}
				BMove = 0;
				break;
			case 's':
				if (direction == "front") {
					direction = null;
					Strayer.setIcon(Strayer.Front);
				}
				FMove = 0;
				break;
			}
			if (LMove==0&&RMove==0&&FMove==0&&BMove==0) timer.stop();
		}
	};
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(A2Image, 0, 0, null);
		this.repaint();
	}
	
	public MapA2(MapManager manager, JFrame Menu) {
		this.Menu = Menu;
		this.manager = manager;
		this.setBounds(0, 0, 900, 600); 
		this.setLayout(null);
		
		timer.setRepeats(true);
		timer.setInitialDelay(0);
		
		JLabel leftBounder = new JLabel();
		leftBounder.setBounds(-50, -50, 110, 600);
		addBoundedComponent(leftBounder);
		JLabel bottomBounder = new JLabel();
		bottomBounder.setBounds(60, 540, 630, 110);
		addBoundedComponent(bottomBounder);
		
		JLabel tree = new JLabel();
		tree.setBounds(90, 0, 180, 420);
		tree.setIcon(tree1Icon);
		addEffectedComponent(tree);
		JLabel treeBound = new JLabel();
		treeBound.setBounds(90, 300, 180, 120);
		addBoundedComponent(treeBound);
		Object.put(tree, treeBound);
		
		JLabel fence = new JLabel();
		fence.setBounds(690, 480, 210, 120);
		fence.setIcon(fence2Icon);
		addEffectedComponent(fence);
		JLabel fenceBound = new JLabel();
		fenceBound.setBounds(690, 600, 260, 50);
		addBoundedComponent(fenceBound);
		Object.put(fence, fenceBound);
		
		JLabel crate = new JLabel();
		crate.setBounds(810, 0, 90, 90);
		crate.setIcon(crate2Icon);
		addEffectedComponent(crate);
		JLabel crateBound = new JLabel();
		crateBound.setBounds(810, -50, 140, 140);
		addBoundedComponent(crateBound);
		Object.put(crate, crateBound);
	}
	
	@Override
	public void moveToTop(JFrame Menu) {
		// TODO Auto-generated method stub
		Menu.removeKeyListener(listener);
		this.setVisible(false);
		this.remove(Strayer);
		EffectedComponent.remove(Strayer);
		Strayer.setIcon(Strayer.Back);
		timer.stop();
		direction = null;
		LMove = 0; BMove = 0; FMove = 0; RMove = 0;
		manager.getMapA1().setVisible(true);
		Strayer.setLocation(Strayer.getX(), 600-Strayer.getHeight());
		manager.getMapA1().setStrayer(Strayer);
	}

	@Override
	public void moveToBottom(JFrame Menu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void moveToRight(JFrame Menu) {
		// TODO Auto-generated method stub
		Menu.removeKeyListener(listener);
		this.setVisible(false);
		this.remove(Strayer);
		EffectedComponent.remove(Strayer);
		Strayer.setIcon(Strayer.Right);
		timer.stop();
		direction = null;
		LMove = 0; BMove = 0; FMove = 0; RMove = 0;
		manager.getMapB2().setVisible(true);
		Strayer.setLocation(0, Strayer.getY());
		manager.getMapB2().setStrayer(Strayer);
	}

	@Override
	public void moveToLeft(JFrame Menu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enterDungeon() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setStrayer(Strayer Strayer) {
		// TODO Auto-generated method stub
		this.Strayer = Strayer;
		addEffectedComponent(Strayer);
		Menu.addKeyListener(listener);
		reArrange();
	}

	@Override
	public void addBoundedComponent(JComponent Component) {
		// TODO Auto-generated method stub
		BoundedComponent.add(Component);
		this.add(Component, JLayeredPane.FRAME_CONTENT_LAYER);
	}

	@Override
	public void addEffectedComponent(JComponent Component) {
		// TODO Auto-generated method stub
		EffectedComponent.add(Component);
		this.add(Component, JLayeredPane.DEFAULT_LAYER);
	}

	public void reArrange() {
		Collections.sort(EffectedComponent, new Comparator<JComponent>() {

			@Override
			public int compare(JComponent c1, JComponent c2) {
				// TODO Auto-generated method stub
				if (c1==Strayer) for (JComponent bound : Object.keySet())
					if(c2==bound) return Integer.compare(c1.getY()+90, Object.get(bound).getY());
				if (c2==Strayer) for (JComponent bound : Object.keySet())
					if(c1==bound)return Integer.compare(Object.get(bound).getY(), c2.getY()+90);
				return Integer.compare(Object.get(c1).getY(), Object.get(c2).getY());
			}
			
		});
		for (int i=0; i<EffectedComponent.size(); i++) {
			JComponent component = EffectedComponent.get(i);
			this.setLayer(component, i+1);
		}
	}
}
