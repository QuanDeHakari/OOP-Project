package Map;

import javax.swing.*;

import Menu.PanelHolder;

public class CommonGate {
	private ComEntrance ComEntrance;
	private ComFront ComFront;
	private ComFinal ComFinal;
	private JLayeredPane PanelHolder;
	private MapManager manager;
	
	public CommonGate(JFrame Menu, JLayeredPane PanelHolder, MapManager manager) {
		this.PanelHolder = PanelHolder;
		this.manager = manager;
		ComEntrance = new ComEntrance(this, Menu);
		PanelHolder.add(ComEntrance, 20);
		ComEntrance.setVisible(false);
		
		ComFront = new ComFront(this, Menu);
		PanelHolder.add(ComFront, 20);
		ComFront.setVisible(false);
		
		ComFinal = new ComFinal(this, Menu);
		PanelHolder.add(ComFinal, 20);
		ComFinal.setVisible(false);
	}
	
	public ComEntrance getComEntrance() {
		return ComEntrance;
	}
	public ComFront getComFront() {
		return ComFront;
	}
	public ComFinal getComFinal() {
		return ComFinal;
	}
	public void Erase() {
		ComFinal.setVisible(false);
		ComEntrance.removeAll();
		PanelHolder.remove(ComEntrance);
		ComFront.removeAll();
		PanelHolder.remove(ComFront);
		ComFinal.removeAll();
		PanelHolder.remove(ComFinal);
		manager.removeGate();
	}
}
