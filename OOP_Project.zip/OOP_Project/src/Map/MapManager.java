package Map;

import javax.swing.*;

import Character.Strayer;

public class MapManager {
	public Strayer Strayer;
	private MapA2 mapA2;
	private MapB2 mapB2;
	private MapA1 mapA1;
	GateManager GateManager;
	
	public MapManager(JFrame Menu, JLayeredPane PanelHolder) {
		Strayer = new Strayer(Menu, PanelHolder);
		mapA2 = new MapA2(this, Menu);
		PanelHolder.add(mapA2, JLayeredPane.DEFAULT_LAYER);
		mapA2.setVisible(true);
		Strayer.intro();
		mapA2.setStrayer(Strayer);
		
		GateManager = new GateManager(Menu, PanelHolder, this);
		
		mapB2 = new MapB2(this, Menu);
		PanelHolder.add(mapB2, 0);
		mapB2.setVisible(false);
		mapB2.addEffectedComponent(GateManager.getB2Gate());
		mapB2.setGateManager(GateManager);
		
		mapA1 = new MapA1(this, Menu);
		PanelHolder.add(mapA1, 0);
		mapA1.setVisible(false);
		mapA1.addEffectedComponent(GateManager.getA1Gate());
		mapA1.setGateManager(GateManager);
	}
	
	public MapA2 getMapA2() {
		return mapA2;
	}
	public MapB2 getMapB2() {
		return mapB2;
	}
	public MapA1 getMapA1() {
		return mapA1;
	}
	public void removeGate() {
		JLabel nullBound = new JLabel();
		nullBound.setBounds(0, 0, 0, 0);
		if (Strayer.getPanelCheck()==mapA1) {
			mapA1.remove(GateManager.getA1Gate());
			GateManager.getGate().replace(GateManager.getA1Gate(), nullBound);
		}
		if (Strayer.getPanelCheck()==mapB2) {
			mapB2.remove(GateManager.getB2Gate());
			GateManager.getGate().replace(GateManager.getB2Gate(), nullBound);
		}
	}
}
