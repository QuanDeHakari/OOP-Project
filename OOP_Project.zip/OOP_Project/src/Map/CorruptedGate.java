package Map;

import javax.swing.*;

import Menu.PanelHolder;

public class CorruptedGate {
	private CorEntrance CorEntrance;
	private CorFront CorFront;
	private CorFinal CorFinal;
	private JLayeredPane PanelHolder;
	private MapManager manager;
	
	public CorruptedGate(JFrame Menu, JLayeredPane PanelHolder, MapManager manager) {
		this.PanelHolder = PanelHolder;
		this.manager = manager;
		CorEntrance = new CorEntrance(this, Menu);
		PanelHolder.add(CorEntrance, 20);
		CorEntrance.setVisible(false);
		
		CorFront = new CorFront(this, Menu);
		PanelHolder.add(CorFront, 20);
		CorFront.setVisible(false);
		
		CorFinal = new CorFinal(this, Menu);
		PanelHolder.add(CorFinal, 20);
		CorFinal.setVisible(false);
	}
	
	public CorEntrance getCorEntrance() {
		return CorEntrance;
	}
	public CorFront getCorFront() {
		return CorFront;
	}
	public CorFinal getCorFinal() {
		return CorFinal;
	}
	public void Erase() {
		CorFinal.setVisible(false);
		CorEntrance.removeAll();
		PanelHolder.remove(CorEntrance);
		CorFront.removeAll();
		PanelHolder.remove(CorFront);
		CorFinal.removeAll();
		PanelHolder.remove(CorFinal);
		manager.removeGate();
	}
}
