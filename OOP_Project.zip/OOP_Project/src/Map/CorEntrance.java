package Map;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Random;

import javax.swing.*;

import Character.Strayer;

public class CorEntrance extends JLayeredPane implements Map{
	
	private JFrame Menu;
	private CorruptedGate CorruptedGate;
	private Random r = new Random();
	private ArrayList<JComponent> BoundedComponent = new ArrayList<JComponent>();
	private ArrayList<JComponent> EffectedComponent = new ArrayList<JComponent>();
	private ArrayList<JComponent> EnemyComponent = new ArrayList<JComponent>();
	private ArrayList<JComponent> CoinComponent = new ArrayList<JComponent>();
	private HashMap<JComponent, JComponent> Object = new HashMap<JComponent, JComponent>();
	private Strayer Strayer;
	private int LMove = 0, RMove = 0, FMove = 0, BMove = 0;
	private String direction;
	private boolean LA = false, RA = false, BA = false, FA = false;
	private Image CEntranceImage = new ImageIcon("src/World Map/Corrupted.png").getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
	
	private Timer timer = new Timer(200, e->{
		if (direction != null) {
		switch (direction) {
		case "left":
			if (LMove+RMove==0)	Strayer.setIcon(Strayer.Left);
			else Strayer.setIcon(LA?Strayer.LeftWalk1:Strayer.LeftWalk2);
			LA = !LA;
			break;
		case "right":
			if (LMove+RMove==0)	Strayer.setIcon(Strayer.Right);
			else Strayer.setIcon(RA?Strayer.RightWalk1:Strayer.RightWalk2);
			RA = !RA;
			break;
		case "back":
			if (FMove+BMove==0)	Strayer.setIcon(Strayer.Back);
			else Strayer.setIcon(BA?Strayer.BackWalk1:Strayer.BackWalk2);
			BA = !BA;
			break;
		case "front":
			if (FMove+BMove==0)	Strayer.setIcon(Strayer.Front);
			else Strayer.setIcon(FA?Strayer.FrontWalk1:Strayer.FrontWalk2);
			FA = !FA;
			break;
		}
		reArrange();
		boolean overlaps = false;
		for (JComponent bounded : BoundedComponent)
			if (bounded.getBounds().intersects(new Rectangle(Strayer.getX()+LMove+RMove, Strayer.getY()+90+FMove+BMove, 60, 30))) overlaps = true;
		if (overlaps==false) Strayer.setLocation(Strayer.getX() + LMove + RMove,Strayer.getY() + FMove + BMove);
		
		for (JComponent coin : CoinComponent)
			if (coin.getBounds().intersects(new Rectangle(Strayer.getX(), Strayer.getY()+90, 60, 30))) {
				Strayer.setCoin(Strayer.getCoin()+1);
				CoinComponent.remove(coin);
				this.remove(coin);
				EffectedComponent.remove(coin);
				Object.remove(coin);
				break;
			}
		
		for (JComponent Enemy : EnemyComponent)
			if (Enemy.getBounds().intersects(new Rectangle(Strayer.getX(), Strayer.getY()+90, 60, 30))) {
				if(Enemy.getWidth()==60) Strayer.setHP(Strayer.getHP()-30);
				if(Enemy.getWidth()==100)Strayer.setHP(Strayer.getHP()-80);
			}
		if (Strayer.getHP()<=0) Strayer.GameOver(this);
		
		if (Strayer.getY()+60<0) moveToTop(Menu);
		}
	});
	KeyListener listener = new KeyListener() {

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			switch(e.getKeyChar()) {
			case 'a':
				if (direction == null) direction = "left";
				LMove = -30;
				break;
			case 'd':
				if (direction == null) direction = "right";
				RMove = 30;
				break;
			case 'w':;
				if (direction == null) direction = "back";
				BMove = -30;
				break;
			case 's':
				if (direction == null) direction = "front";
				FMove = 30;
				break;
			}
			timer.start();
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			switch(e.getKeyChar()) {
			case 'a':
				if (direction == "left") {
					direction = null;
					Strayer.setIcon(Strayer.Left);
				}
				LMove = 0;
				break;
			case 'd':
				if (direction == "right") {
					direction = null;
					Strayer.setIcon(Strayer.Right);
				}
				RMove = 0;
				break;
			case 'w':
				if (direction == "back") {
					direction = null;
					Strayer.setIcon(Strayer.Back);
				}
				BMove = 0;
				break;
			case 's':
				if (direction == "front") {
					direction = null;
					Strayer.setIcon(Strayer.Front);
				}
				FMove = 0;
				break;
			}
			if (LMove==0&&RMove==0&&FMove==0&&BMove==0) timer.stop();
		}
	};
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(CEntranceImage, 0, 0, null);
		this.repaint();
	}
	
	public CorEntrance(CorruptedGate CorruptedGate, JFrame Menu) {
		this.CorruptedGate = CorruptedGate;
		this.Menu = Menu;
		this.setBounds(0, 0, 900, 600);
		this.setLayout(null);
		
		JLabel leftBound = new JLabel();
		leftBound.setBounds(0, -50, 60, 700);
		addBoundedComponent(leftBound);
		JLabel rightBound = new JLabel();
		rightBound.setBounds(840, -50, 60, 700);
		addBoundedComponent(rightBound);
		JLabel bottomBound = new JLabel();
		bottomBound.setBounds(0, 600, 900, 50);
		addBoundedComponent(bottomBound);
		
		for (int i=0; i<r.nextInt(5); i++) addRandomStone();
		for (int i=0; i<r.nextInt(2); i++) addRandomBigStone();
		for (int i=0; i<r.nextInt(2)+5; i++)addRandomBigSlime();
		for (int i=0; i<r.nextInt(2)+15; i++) addRandomSlime();
		for (int i=0; i<r.nextInt(4)+1; i++) addRandomCoin();
		for (int i=0; i<r.nextInt(5)+5; i++) addGlitch();
	}
	
	@Override
	public void moveToTop(JFrame Menu) {
		// TODO Auto-generated method stub
		Menu.removeKeyListener(listener);
		this.setVisible(false);
		this.remove(Strayer);
		EffectedComponent.remove(Strayer);
		Strayer.setIcon(Strayer.Back);
		timer.stop();
		direction = null;
		LMove = 0; BMove = 0; FMove = 0; RMove = 0;
		CorruptedGate.getCorFront().setVisible(true);
		Strayer.setLocation(Strayer.getX(), 600-Strayer.getHeight());
		CorruptedGate.getCorFront().setStrayer(Strayer);
	}

	@Override
	public void moveToBottom(JFrame Menu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void moveToRight(JFrame Menu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void moveToLeft(JFrame Menu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void enterDungeon() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setStrayer(Strayer Strayer) {
		// TODO Auto-generated method stub
		this.Strayer = Strayer;
		addEffectedComponent(Strayer);
		Menu.addKeyListener(listener);
		reArrange();
	}

	@Override
	public void addBoundedComponent(JComponent Component) {
		// TODO Auto-generated method stub
		BoundedComponent.add(Component);
		this.add(Component, JLayeredPane.FRAME_CONTENT_LAYER);
	}

	@Override
	public void addEffectedComponent(JComponent Component) {
		// TODO Auto-generated method stub
		EffectedComponent.add(Component);
		this.add(Component, JLayeredPane.DEFAULT_LAYER);
	}

	public void reArrange() {
		Collections.sort(EffectedComponent, new Comparator<JComponent>() {

			@Override
			public int compare(JComponent c1, JComponent c2) {
				// TODO Auto-generated method stub
				if (c1==Strayer) return Integer.compare(c1.getY()+90, Object.get(c2).getY());
				if (c2==Strayer) return Integer.compare(Object.get(c1).getY(), c2.getY()+90);
				return Integer.compare(Object.get(c1).getY(), Object.get(c2).getY());
			}
			
		});
		for (int i=0; i<EffectedComponent.size(); i++) {
			JComponent component = EffectedComponent.get(i);
			this.setLayer(component, i+1);
		}
	}
	
	public void addRandomStone() {
		int x, y;
		boolean overlaps;
		do {
			x = r.nextInt(28)*30+30;
			y = r.nextInt(14)*30+60;
			overlaps = false;
			for (JComponent object : EffectedComponent) {
				if (object.getBounds().intersects(new Rectangle(x, y, 30, 30))) {
					overlaps = true;
					break;
				}
			}
		} while (overlaps);
		JLabel Stone = new JLabel();
		Stone.setBounds(x, y, 30, 30);
		switch (r.nextInt(2)) {
		case 0: 
			Stone.setIcon(Stone1Icon);
			break;
		case 1:
			Stone.setIcon(Stone2Icon);
			break;
		}
		addEffectedComponent(Stone);
		JLabel Bound = new JLabel();
		Bound.setBounds(x, y, 30, 30);
		addBoundedComponent(Bound);
		Object.put(Stone, Bound);
	}
	public void addRandomBigStone() {
		int x, y;
		boolean overlaps;
		do {
			x = r.nextInt(6)*120+60;
			y = r.nextInt(2)*180+(r.nextInt(2)+1)*60;
			overlaps = false;
			for (JComponent object : EffectedComponent) {
				if (object.getBounds().intersects(new Rectangle(x, y, 30, 30))) {
					overlaps = true;
					break;
				}
			}
		} while (overlaps);
		JLabel Stone = new JLabel();
		Stone.setBounds(x, y, 120, 180);
		switch (r.nextInt(2)) {
		case 0: 
			Stone.setIcon(bigStone1Icon);
			break;
		case 1:
			Stone.setIcon(bigStone2Icon);
			break;
		}
		addEffectedComponent(Stone);
		JLabel Bound = new JLabel();
		Bound.setBounds(x, y+120, 120, 60);
		addBoundedComponent(Bound);
		Object.put(Stone, Bound);
	}
	public void addRandomSlime() {
		int x, y;
		boolean overlaps;
		do {
			x = r.nextInt(13)*60+60;
			y = r.nextInt(8)*60+60;
			overlaps = false;
			for (JComponent object : EffectedComponent) {
				if (object.getBounds().intersects(new Rectangle(x, y, 60, 60))) {
					overlaps = true;
					break;
				}
			}
		} while (overlaps);
		JLabel Slime = new JLabel();
		Slime.setBounds(x, y, 60, 60);
		Slime.setIcon(cslime);
		addEffectedComponent(Slime);
		Object.put(Slime, Slime);
		EnemyComponent.add(Slime);
	}
	public void addRandomBigSlime() {
		int x, y;
		boolean overlaps;
		do {
			x = r.nextInt(8)*100+60;
			y = r.nextInt(5)*100+60;
			overlaps = false;
			for (JComponent object : EffectedComponent) {
				if (object.getBounds().intersects(new Rectangle(x, y, 100, 100))) {
					overlaps = true;
					break;
				}
			}
		} while (overlaps);
		JLabel Slime = new JLabel();
		Slime.setBounds(x, y, 100, 100);
		Slime.setIcon(cbigSlime);
		addEffectedComponent(Slime);
		Object.put(Slime, Slime);
		EnemyComponent.add(Slime);
	}
	public void addRandomCoin() {
		int x, y;
		boolean overlaps;
		do {
			x = r.nextInt(13)*60+60;
			y = r.nextInt(8)*60+60;
			overlaps = false;
			for (JComponent object : EffectedComponent) {
				if (object.getBounds().intersects(new Rectangle(x, y, 60, 60))) {
					overlaps = true;
					break;
				}
			}
		} while (overlaps);
		JLabel Coin = new JLabel();
		Coin.setBounds(x, y, 60, 60);
		Coin.setIcon(coin);
		addEffectedComponent(Coin);
		Object.put(Coin, Coin);
		CoinComponent.add(Coin);
	}
	public void addGlitch() {
		int x = r.nextInt(840);
		int y = r.nextInt(540);
		JLabel Glitch = new JLabel();
		Glitch.setBounds(x, y, 60, 60);
		switch (r.nextInt(3)) {
		case 0: 
			Glitch.setIcon(glitch1Icon);
			break;
		case 1:
			Glitch.setIcon(glitch2Icon);
			break;
		case 2:
			Glitch.setIcon(glitch3Icon);
			break;
		}
		this.add(Glitch, JLayeredPane.PALETTE_LAYER);
	}
}
