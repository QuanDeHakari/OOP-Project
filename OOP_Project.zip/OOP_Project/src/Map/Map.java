package Map;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;

import Character.Strayer;

public interface Map {
	ImageIcon tree1Icon = new ImageIcon(new ImageIcon("src/All Object/Tree1.png").getImage().getScaledInstance(180, 420, Image.SCALE_DEFAULT));
	ImageIcon fence1Icon = new ImageIcon(new ImageIcon("src/All Object/Fence1.png").getImage().getScaledInstance(900, 120, Image.SCALE_DEFAULT));
	ImageIcon fence2Icon = new ImageIcon(new ImageIcon("src/All Object/Fence2.png").getImage().getScaledInstance(210, 120, Image.SCALE_DEFAULT));
	ImageIcon crate1Icon = new ImageIcon(new ImageIcon("src/All Object/Crate1.png").getImage().getScaledInstance(90, 90, Image.SCALE_DEFAULT));
	ImageIcon crate2Icon = new ImageIcon(new ImageIcon("src/All Object/Crate2.png").getImage().getScaledInstance(90, 90, Image.SCALE_DEFAULT));
	ImageIcon blockedWoodIcon = new ImageIcon(new ImageIcon("src/All Object/BlockWood.png").getImage().getScaledInstance(90, 240, Image.SCALE_DEFAULT));
	ImageIcon Stone1Icon = new ImageIcon(new ImageIcon("src/All Object/Stone1.png").getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT));
	ImageIcon Stone2Icon = new ImageIcon(new ImageIcon("src/All Object/Stone2.png").getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT));
	ImageIcon bigStone1Icon = new ImageIcon(new ImageIcon("src/All Object/BigStone1.png").getImage().getScaledInstance(120, 180, Image.SCALE_DEFAULT));
	ImageIcon bigStone2Icon = new ImageIcon(new ImageIcon("src/All Object/BigStone2.png").getImage().getScaledInstance(120, 180, Image.SCALE_DEFAULT));
	ImageIcon glitch1Icon = new ImageIcon(new ImageIcon("src/All Object/Glitch1.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT));
	ImageIcon glitch2Icon = new ImageIcon(new ImageIcon("src/All Object/Glitch2.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT));
	ImageIcon glitch3Icon = new ImageIcon(new ImageIcon("src/All Object/Glitch3.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT));
	ImageIcon coin = new ImageIcon(new ImageIcon("src/All Object/Coin 50x70.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT));
	ImageIcon chest = new ImageIcon("src/All Object/Chest.png");
	ImageIcon slime = new ImageIcon(new ImageIcon("src/All Object/OriginalSlimeLabel.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT));
	ImageIcon bigSlime = new ImageIcon(new ImageIcon("src/All Object/OriginalSlime.png").getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
	ImageIcon cslime = new ImageIcon(new ImageIcon("src/All Object/CorruptedSlimeLabel.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT));
	ImageIcon cbigSlime = new ImageIcon(new ImageIcon("src/All Object/CorruptedSlime.png").getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
	
	public void moveToTop(JFrame Menu);
	public void moveToBottom(JFrame Menu);
	public void moveToRight(JFrame Menu);
	public void moveToLeft(JFrame Menu);
	public void enterDungeon();
	public void setStrayer(Strayer Strayer);
	public void addBoundedComponent(JComponent Component);
	public void addEffectedComponent(JComponent Component);
}
