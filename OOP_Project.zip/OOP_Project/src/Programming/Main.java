package Programming;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;

import Menu.MenuPanel;

public class Main {

	private JFrame frame;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Main() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setPreferredSize(new Dimension(900, 700));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setResizable(false);
		
		frame.getContentPane().add(new MenuPanel(frame));
		frame.pack();
	}

}
