package Programming;

import java.awt.Dimension;

import javax.swing.JFrame;

import Menu.MenuPanel;

public class NewWindowGame {

	JFrame frame = new JFrame();
	
	public NewWindowGame() {
		frame.getContentPane().setPreferredSize(new Dimension(900, 700));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		frame.getContentPane().add(new MenuPanel(frame));
		frame.pack();
	}
}
