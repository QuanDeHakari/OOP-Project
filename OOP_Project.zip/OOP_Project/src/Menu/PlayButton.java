package Menu;

import java.awt.event.*;

import javax.swing.*;

import Map.MapManager;

public class PlayButton extends JLabel implements MouseListener{

	private MenuPanel menuPanel;
	private PanelHolder PanelHolder;
	ImageIcon playIcon = new ImageIcon("src/Menu image/Play button.png");
	ImageIcon playIcon1 = new ImageIcon("src/Menu image/Play button 1.png");
	
	public PlayButton(MenuPanel menuPanel, JFrame Menu) {
		this.menuPanel = menuPanel;
		this.setBounds(350, 150, 200, 100);
		this.setIcon(playIcon);
		this.addMouseListener(this);
		
		PanelHolder = new PanelHolder(menuPanel);
		Menu.add(PanelHolder);
		MapManager manager = new MapManager(Menu, PanelHolder);
		PanelHolder.setStrayer(manager.Strayer);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		menuPanel.setVisible(false);
		PanelHolder.setVisible(true);
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(playIcon1);
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(playIcon);
	}
}
