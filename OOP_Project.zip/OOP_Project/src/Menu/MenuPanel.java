package Menu;

import java.awt.*;

import javax.swing.*;

public class MenuPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private CreditsButton creditsButton;
	private ExitButton exitButton;
	private PlayButton playButton;
	private Image menuImage = new ImageIcon("src/Menu Image/Menu.png").getImage().getScaledInstance(900, 700, Image.SCALE_DEFAULT);
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(menuImage, 0, 0, null);
	}
	
	public MenuPanel(JFrame Menu) {
		this.setBounds(0, 0, 900, 700); 
		this.setLayout(null);
		creditsButton  = new CreditsButton(this, Menu);
		exitButton = new ExitButton(Menu);
		playButton = new PlayButton(this, Menu);
		this.add(creditsButton);
		this.add(exitButton);
		this.add(playButton);
	}
}
