package Menu;

import java.awt.event.*;

import javax.swing.*;

public class CreditsButton extends JLabel implements MouseListener{
	
	private MenuPanel menuPanel;
	private JFrame Menu;;
	ImageIcon creditsIcon = new ImageIcon("src/Menu Image/Credits button.png");
	ImageIcon creditsIcon1 = new ImageIcon("src/Menu Image/Credits button 1.png");
	public CreditsButton(MenuPanel menuPanel, JFrame Menu){
		this.menuPanel = menuPanel;
		this.Menu = Menu;
		this.setBounds(350, 250, 200, 100);
		this.setIcon(creditsIcon);
		this.addMouseListener(this);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(creditsIcon1);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(creditsIcon);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		menuPanel.setVisible(false);
		Menu.add(new CreditsPanel(menuPanel, Menu));
	}
}
