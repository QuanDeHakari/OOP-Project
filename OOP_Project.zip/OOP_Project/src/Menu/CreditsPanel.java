package Menu;

import java.awt.*;

import javax.swing.*;

public class CreditsPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private BackButton backButton;
	private Image creditsImage = new ImageIcon("src/Menu Image/CREDITS.png").getImage();
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(creditsImage, 0, 0, null);
		this.repaint();
	}
	
	public CreditsPanel(MenuPanel menuPanel, JFrame Menu) {
		this.setBounds(0, 0, 900, 700);
		this.setLayout(null);
		backButton = new BackButton(this, menuPanel, Menu);
		this.add(backButton);
	}
}
