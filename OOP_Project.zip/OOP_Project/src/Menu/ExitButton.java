package Menu;

import java.awt.event.*;

import javax.swing.*;

public class ExitButton extends JLabel implements MouseListener{
	
	private JFrame Menu;
	ImageIcon exitIcon = new ImageIcon("src/Menu Image/Exit button.png");
	ImageIcon exitIcon1 = new ImageIcon("src/Menu Image/Exit button 1.png");
	public ExitButton(JFrame Menu) {
		this.Menu = Menu;
		this.setBounds(350, 350, 200, 100);
		this.setIcon(exitIcon);
		this.addMouseListener(this);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		Menu.dispose();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(exitIcon1);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(exitIcon);
	}

}
