package Menu;

import javax.swing.*;

import Character.Strayer;
import ToolBar.*;

public class PanelHolder extends JLayeredPane{

	private ToolBar ToolBar;
	
	public PanelHolder(JPanel menuPanel) {
		this.setBounds(0, 0, 900, 700);
		this.setLayout(null);
		this.setVisible(false);
		
		ToolBar = new ToolBar(this, menuPanel);
		this.add(ToolBar, JLayeredPane.DEFAULT_LAYER);
	}

	public void setStrayer(Strayer Strayer) {
		ToolBar.setStrayer(Strayer);
	}

	public ToolBar getToolBar() {
		return ToolBar;
	}

	public void setToolBar(ToolBar toolBar) {
		ToolBar = toolBar;
	}
}
