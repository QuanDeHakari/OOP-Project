package Menu;

import java.awt.event.*;
import javax.swing.*;

public class BackButton extends JLabel implements MouseListener{
	
	private CreditsPanel creditsPanel;
	private MenuPanel menuPanel;
	private JFrame Menu;
	ImageIcon backIcon = new ImageIcon("src/Menu Image/Back button.png");
	ImageIcon backIcon1 = new ImageIcon("src/Menu Image/Back button 1.png");
	public BackButton(CreditsPanel creditsPanel, MenuPanel menuPanel, JFrame Menu) {
		this.creditsPanel = creditsPanel;
		this.menuPanel = menuPanel;
		this.Menu = Menu;
		this.setBounds(30, 20, 130, 50);
		this.setIcon(backIcon);
		this.addMouseListener(this);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		menuPanel.setVisible(true);
		Menu.remove(creditsPanel);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(backIcon1);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(backIcon);
	}
}
