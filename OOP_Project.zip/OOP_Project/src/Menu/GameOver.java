package Menu;

import java.awt.Image;
import java.awt.event.*;

import javax.swing.*;

import Programming.NewWindowGame;

public class GameOver extends JLabel{

	private JFrame Menu;
	private Timer delay;
	ImageIcon GameOver = new ImageIcon(new ImageIcon("src/Menu Image/GameOver.png").getImage().getScaledInstance(900, 700, Image.SCALE_DEFAULT));
	
	public GameOver(JFrame Menu) {
		this.Menu = Menu;
		this.setBounds(0, 0, 900, 700);
		this.setIcon(GameOver);
		Menu.add(this);
		delay = new Timer(10000, e->{
			CreateWindow();
		});
		delay.setRepeats(false);
		delay.start();
	}
	
	public void CreateWindow() {
		Menu.dispose();
		NewWindowGame newgame = new NewWindowGame();
	}
}
