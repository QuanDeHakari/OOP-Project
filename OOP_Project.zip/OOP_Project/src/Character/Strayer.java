package Character;

import java.awt.Font;
import java.awt.Image;
import java.util.Random;

import javax.swing.*;
import Menu.*;

public class Strayer extends JLabel{

	private int HP, maxHP;
	private int coin;
	private int xCheck, yCheck;
	private JLayeredPane PanelCheck;
	private JFrame Menu;
	private JLayeredPane PanelHolder;
	private JLabel Text;
	public ImageIcon Back = new ImageIcon(new ImageIcon("src/Strayer Package/Back.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon BackWalk1 = new ImageIcon(new ImageIcon("src/Strayer Package/BackWalk1.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon BackWalk2 = new ImageIcon(new ImageIcon("src/Strayer Package/BackWalk2.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon Front = new ImageIcon(new ImageIcon("src/Strayer Package/Front.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon FrontWalk1 = new ImageIcon(new ImageIcon("src/Strayer Package/FrontWalk1.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon FrontWalk2 = new ImageIcon(new ImageIcon("src/Strayer Package/FrontWalk2.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon Left = new ImageIcon(new ImageIcon("src/Strayer Package/Left.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon LeftWalk1 = new ImageIcon(new ImageIcon("src/Strayer Package/LeftWalk1.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon LeftWalk2 = new ImageIcon(new ImageIcon("src/Strayer Package/LeftWalk2.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon Right = new ImageIcon(new ImageIcon("src/Strayer Package/Right.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon RightWalk1 = new ImageIcon(new ImageIcon("src/Strayer Package/RightWalk1.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	public ImageIcon RightWalk2 = new ImageIcon(new ImageIcon("src/Strayer Package/RightWalk2.png").getImage().getScaledInstance(60, 120, Image.SCALE_DEFAULT));
	
	public Strayer(JFrame Menu, JLayeredPane PanelHolder) {
		this.Menu = Menu;
		this.PanelHolder = PanelHolder;
		maxHP = new Random().nextInt(10)+150;
		setHP(maxHP);
		this.setBounds(270, 270, 60, 120);
		this.setIcon(Right);
		
		Text = new JLabel();
		Text.setBounds(200, 10, 500, 80);
		Text.setFont(new Font("Times New Roman", Font.PLAIN, 25));
	}
	
	public void GameOver(JLayeredPane diepoint) {
		new GameOver(Menu);
		diepoint.setVisible(false);
		((PanelHolder) PanelHolder).getToolBar().setVisible(false);
		if (((PanelHolder) PanelHolder).getToolBar().Profile.isActing()) ((PanelHolder) PanelHolder).getToolBar().Profile.Container.setVisible(false);
		if (((PanelHolder) PanelHolder).getToolBar().Coin.isActing()) ((PanelHolder) PanelHolder).getToolBar().Coin.Container.setVisible(false);
		SwingUtilities.invokeLater(() -> {
		    PanelHolder.removeAll();
		    Menu.removeAll();
		});
	}

	public int getHP() {
		return HP;
	}

	public void setHP(int hP) {
		HP = hP;
	}

	public int getMaxHP() {
		return maxHP;
	}

	public void setMaxHP(int maxHP) {
		this.maxHP = maxHP;
	}

	public int getxCheck() {
		return xCheck;
	}

	public void setxCheck(int xCheck) {
		this.xCheck = xCheck;
	}

	public int getyCheck() {
		return yCheck;
	}

	public void setyCheck(int yCheck) {
		this.yCheck = yCheck;
	}

	public JLayeredPane getPanelCheck() {
		return PanelCheck;
	}

	public void setPanelCheck(JLayeredPane panelCheck) {
		PanelCheck = panelCheck;
	}

	public int getCoin() {
		return coin;
	}

	public void setCoin(int coin) {
		this.coin = coin;
	}
	
	public JLabel getMessage() {
		return Text;
	}
	
	public void intro() {
		Timer t1 = new Timer(2000, e->{
			Text.setText(null);
		});
		Timer t2 = new Timer(6000, e->{
			Text.setText("Good luck");
			t1.start();
		});
		Timer t3 = new Timer(6000, e->{
			Text.setText("But you won't make it far");
			t2.start();
		});
		Timer t4 = new Timer(7000, e->{
			Text.setText("By entering gates");
			t3.start();
		});
		Timer t5 = new Timer(7000, e->{
			Text.setText("Try to gain coins as much as possible");
			t4.start();
		});
		Timer t6 = new Timer(3000, e->{
			Text.setText("This is OOP project make by On Minh Quan");
			t5.start();
		});
		Timer t7 = new Timer(1000, e->{
			Text.setText("Hi");
			t6.start();
		});
		t1.setRepeats(false);
		t2.setRepeats(false);
		t3.setRepeats(false);
		t4.setRepeats(false);
		t5.setRepeats(false);
		t6.setRepeats(false);
		t7.setRepeats(false);
		t7.start();
	}
}
