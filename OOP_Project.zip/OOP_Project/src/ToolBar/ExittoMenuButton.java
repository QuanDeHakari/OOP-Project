package ToolBar;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class ExittoMenuButton extends JLabel implements MouseListener{

	private JLayeredPane PanelHolder;
	private JPanel menuPanel;
	ImageIcon ExittoMenuIcon = new ImageIcon("src/ToolBar Image/ExittoMenu.png");
	ImageIcon ExittoMenuIcon1 = new ImageIcon("src/ToolBar Image/ExittoMenu1.png");
	
	public ExittoMenuButton(JLayeredPane PanelHolder, JPanel menuPanel) {
		this.PanelHolder = PanelHolder;
		this.menuPanel = menuPanel;
		this.setBounds(700, 10, 190, 80);
		this.setIcon(ExittoMenuIcon);
		this.addMouseListener(this);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		PanelHolder.setVisible(false);
		menuPanel.setVisible(true);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(ExittoMenuIcon1);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		this.setIcon(ExittoMenuIcon);
	}

}

