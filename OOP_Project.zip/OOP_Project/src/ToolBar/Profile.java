package ToolBar;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import Character.Strayer;

public class Profile extends JLabel implements MouseListener{
	
	private JLayeredPane PanelHolder;
	public JLabel Container;
	private Strayer Strayer;
	private boolean acting = false;
	ImageIcon profile1 = new ImageIcon("src/Strayer Package/Profile.png");
	ImageIcon profile2 = new ImageIcon("src/Strayer Package/ProfilePress.png");
	
	public Profile(JLayeredPane PanelHolder) {
		this.PanelHolder = PanelHolder;
		this.setBounds(10, 10, 90, 80);
		this.setIcon(profile1);
		this.addMouseListener(this);
		
		Container = new JLabel();
		Container.setBounds(0, 575, 100, 25);
		Container.setBackground(new Color(0xa55555));
		Container.setOpaque(true);
		Container.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		PanelHolder.add(Container, JLayeredPane.POPUP_LAYER);
		Container.setVisible(false);
		Timer timer = new Timer(100, e->{
			Container.setText("HP: "+Strayer.getHP()+"/"+Strayer.getMaxHP());
		});
		timer.setRepeats(true);
		timer.start();
	}
	
	public void setStrayer(Strayer Strayer) {
		this.Strayer = Strayer;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		if (acting==false) {
			this.setIcon(profile2);
			acting = !acting;
			Container.setVisible(true);
		} else {
			this.setIcon(profile1);
			acting = !acting;
			Container.setVisible(false);
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		if (acting==false) this.setIcon(profile2);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		if (acting==false) this.setIcon(profile1);
	}

	public boolean isActing() {
		return acting;
	}

	public void setActing(boolean acting) {
		this.acting = acting;
	}

}