package ToolBar;

import java.awt.Image;

import javax.swing.*;

import Character.*;

public class ToolBar extends JPanel {

	private static final long serialVersionUID = 1L;
	ExittoMenuButton ExitButton;
	public Profile Profile;
	public Coin Coin;
	private ImageIcon Bar = new ImageIcon(new ImageIcon("src/ToolBar Image/Bar.png").getImage().getScaledInstance(900, 100, Image.SCALE_DEFAULT));
	
	public ToolBar(JLayeredPane PanelHolder, JPanel menuPanel) {
		this.setBounds(0, 600, 900, 100);
		this.setLayout(null);
		this.setVisible(true);
		
		Profile = new Profile(PanelHolder);
		Coin = new Coin(PanelHolder);
		ExitButton = new ExittoMenuButton(PanelHolder, menuPanel);
	}
	
	public void setStrayer(Strayer Strayer) {
		Profile.setStrayer(Strayer);
		Coin.setStrayer(Strayer);
		this.add(Profile);
		this.add(Coin);
		this.add(Strayer.getMessage());
		this.add(ExitButton);
		
		JLabel backGround = new JLabel();
		backGround.setBounds(0, 0, 900, 100);
		backGround.setIcon(Bar);
		this.add(backGround);
	}
}
